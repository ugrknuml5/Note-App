package com.example.notesapp

import com.google.gson.Gson

class MockApiService {
    fun fetchData(): String? {
        val note = Note(1, "MockApiNote", "Created by mock api")
        val listOfNotes = listOf(note)
        val jsonString = Gson().toJson(listOfNotes)
        return Gson().toJson(listOfNotes)
    }
}