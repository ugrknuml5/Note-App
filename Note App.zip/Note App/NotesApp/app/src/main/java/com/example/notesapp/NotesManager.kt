package com.example.notesapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class NotesManager(private val context: Context) {
    private val noteDao = NoteDBHelper(context).getAllNotes()
    private val notesLiveData: MutableLiveData<List<Note>> = MutableLiveData()
    fun getNotesLiveData(): LiveData<List<Note>> {
        return notesLiveData
    }
    fun updateNotes(newNotes: String?) {
        val dbHelper = NoteDBHelper(context)

        if (newNotes != null) {
            val notesList: List<Note> = Gson().fromJson(newNotes, object : TypeToken<List<Note>>() {}.type)
            for (newNote in notesList) {
                dbHelper.insertNote(newNote)
            }
        }
        showNotification("New notes available!")
    }
    private fun showNotification(message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("notes_channel", "Notes Channel", NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, "notes_channel")
            .setContentTitle("Notes App")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_down) // Replace with your own icon
            .build()

        notificationManager.notify(1, notification)
    }




}

