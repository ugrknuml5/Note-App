package com.example.notesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.PeriodicWorkRequest
import androidx.work.PeriodicWorkRequestBuilder
import com.example.notesapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: com.example.notesapp.NoteDBHelper
    private lateinit var notesAdapter: com.example.notesapp.NotesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        db= com.example.notesapp.NoteDBHelper(this)
        notesAdapter= com.example.notesapp.NotesAdapter(db.getAllNotes(), this)
        binding.notesRecyclerView.layoutManager=LinearLayoutManager(this)
        binding.notesRecyclerView.adapter=notesAdapter

        binding.addButton.setOnClickListener {
            val intent = Intent(this, com.example.notesapp.AddNotes::class.java)
            startActivity(intent)
        }
        schedulePeriodicWork()
        binding.seeWeather.setOnClickListener {
            // Create an Intent to start the Weather activity
            val intent = Intent(this, com.example.notesapp.Weather::class.java)

            // Start the Weather activity
            startActivity(intent)
        }

    }
    private fun schedulePeriodicWork() {
        // Schedule the periodic work when the app is started
        // Change repeatIntervalTimeUnit to TimeUnit.MINUTES
        var periodicWorkRequest = PeriodicWorkRequestBuilder<MyWorker>(
            repeatInterval = 1,
            repeatIntervalTimeUnit = TimeUnit.MINUTES
        ).build()


        WorkManager.getInstance(applicationContext).enqueue(periodicWorkRequest)
    }
    override fun onResume() {
        super.onResume()
        notesAdapter.refreshData(db.getAllNotes())
    }
}